public interface Flying
{
    public String fly();
}