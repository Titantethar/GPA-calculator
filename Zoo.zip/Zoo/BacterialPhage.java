
/**
 * Write a description of class Bacterial_animal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BacterialPhage extends Animal implements Flying
{
    public BacterialPhage()
    {
        this("Bacterial Brant", "I suck the cytoplasm of other cells.");
    }
    
    public BacterialPhage(String name, String description) {
        super(name, description);
    }
    
    @Override
    
    
    public String eat() {
        return "Eats other cells.";
    }
    
    @Override 
    
    
    public String makeNoise() {
        return "*Moving noises*";
    }
    
    @Override
    
    public String fly() {
        return "It moves slowly through the air. Slowly consuming anthing it touches.";
    }
}
