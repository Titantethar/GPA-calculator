/**
 * Write a description of class goomba here. - it's a goomba
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class goomba extends Animal
implements Walking
{
    // instance variables - replace the example below with your own
    public goomba()
    {
        this("Goombro the Goomba","Uh, my head hurts");
    }
    public goomba(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Eats dirts and if they are lucky a super mushroom";
    }
    @Override
    public String makeNoise()
    {
        return "Kew Kew";
    }
    @Override
    public String walk()
    {
       return "Shroom"; 
    }
}

