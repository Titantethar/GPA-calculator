
/**
 * Write a description of class shark here. - Eats fishes
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class shark extends Animal
implements Swimming
{
    // instance variables - replace the example below with your own
    public shark()
    {
        this("Sushi the Great Shark", "I'ma eat Mario, Crunch Crunch");
    }
    public shark(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Chews on fish and Mario";
    }
    @Override
    public String makeNoise()
    {
        return "Blub, Blob";
    }
    @Override
    public String swim()
    {
       return "Squish"; 
    }
}
