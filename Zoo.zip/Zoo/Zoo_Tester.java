import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
import java.util.*;
/**
 * Write a description of class Zoo_Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Zoo_Tester
{
    public static void main(String[] args) throws InterruptedException
    {   
        double cash = -3.50;
        double odds;
        double slot1;
        double slot2;
        double slot3;
        int range = 100 - 1 + 1;
        int range2 = 20 - 1 + 1;
        String Government = "Democratic";
        List<Animal> animals = new ArrayList<Animal>();

        System.out.println("Welcome to the Zoo! You are now 3.50 in debt for your ticket please pay it off!\n");
        System.out.println("         .-----------------._,,");
        System.out.println("         |       Zoo        (_')='");
        System.out.println("         |     Wondorus?    |||                __");
        System.out.println("         |   or Dangerous   ||#/_____       .-/  |");
        System.out.println("  ssgg   |------------------|/# # # #/    .''  ..'----,_");
        System.out.println("         |       |/         | /##_#_#// =:.'-|         )\"");
        System.out.println("         |      _(')        | ||||||||   ::   |  ,_   /  `");
        System.out.println("         ;    o(_,\\        | I I  I I    `   [|_/\\_]");
        
        
        System.out.println("Building the Enclosures");
        //delayDots(3);
        System.out.println("Populating Animals");
        populateAnimals(animals);
        //delayDots(3);
        System.out.println("Hiring zookeepers");
        //delayDots(3);

        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do. \n");
        String text = in.nextLine();
        String msg = "";

        while(!text.equals("leave"))
        {
            switch(text)
            {
                case "help":
                msg = "LookUp, Look Around, LookDown, Leave, lunchtime, ConsessionsStand, Add Money, My Wallet, Amusement Park, Casino, Gift Shop";
                break;

                case "Visit Cages":
                msg = visitCages(animals);
                break;

                case "lunchtime":
                msg = lunchtime(animals);
                break;

                case "LookUp": 
                msg = LookUp(animals);
                break;

                case "LookDown":
                msg = LookDown(animals);
                break;

                case "LookAround":
                msg = LookAround(animals);
                break;

                case "Add Money":
                msg = "How much $5.00, $10.00, $20.00?";
                break;

                case "$5.00":
                msg = "You added $5.00 to your account.";
                cash = cash + 5.00;
                break;

                case "$10.00":
                msg = "You added $10.00 to your account.";
                cash = cash + 10.00;
                break;

                case "$20.00":
                msg = "You added $20.00 to your account.";
                cash = cash + 20.00;
                break;

                case "My Wallet":
                msg = "";
                odds = (int)(Math.random() * range) + 1;
                if(odds <= 10)
                {
                    System.out.println("Your Wallet has been snatched.");
                    cash = 0.0;
                    System.out.println("You now have $" + cash);
                }
                else
                {
                    System.out.println("You have $" + cash);
                }
                break;

                case "ConsessionsStand":
                msg = "What do you want? Hot Dog, Drink, Nachos";
                break;

                case "Hot Dog":
                if(cash >= 2.50)
                {
                    msg = "that'll be $2.50";
                    cash = cash - 2.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Drink":
                if(cash >= 1.50)
                {
                    msg = "that'll be $1.50";
                    cash = cash - 1.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Nachos":
                if(cash >= 3.50)
                {
                    msg = "that'll be $3.50";
                    cash = cash - 3.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Gift Shop":
                msg = "What do you want from the gift shop. Toy, Cup, Wallet, Stuffed Animal?";
                break;

                case "Toy":
                if(cash >= 5.00)
                {
                    msg = "that'll be $5.00";
                    cash = cash - 5.00;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Cup":
                if(cash >= 3.50)
                {
                    msg = "that'll be $3.50";
                    cash = cash - 3.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Wallet":
                if(cash >= 2.50)
                {
                    msg = "that'll be $2.50";
                    cash = cash - 2.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Stuffed Animal":
                if(cash >= 6.00)
                {
                    msg = "that'll be $6.00";
                    cash = cash - 6.00;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Amusement Park":
                msg = "Have Fun!!!";
                System.out.println("         o");
                System.out.println("       o |");
                System.out.println("       |");
                System.out.println("     .       .           ._._.    _                     .===.");
                System.out.println("     |`      |`        ..'| |`.. |H|        .--.      .:'   `:.");
                System.out.println("    ///-...-/|/         |- o -|  |H|`.     /||||/     ||     ||");
                System.out.println("._.'//////,'|||`._.    '`.|||.'` |\\||:. .'||||||`.   `:.   .:'");
                System.out.println("||||||||||||[ ]||||      |_T_|   |:`:.--'||||||||||`--..`=:='...");
                break;

                case "Vote":
                msg = "Who do you want to vote for Wesley = jesus, Connor = Hitler, Noah = Stalin";
                break;

                case "Wesley":
                if(Government == "Democractic")
                {
                    msg = "Nothing Changes";
                }
                if(Government == "Communism")
                {
                    msg = "You Changed America to Democractic";
                    Government = "Democractic";
                }
                if(Government == "Facist")
                {
                    msg = "The entire population was massacred";
                    Government = "Democractic";
                }
                break;

                case "Connor":
                if(Government == "Democractic")
                {
                    msg = "Germany Invades the U.S with mass tanks.";
                    Government = "Facist";
                }
                if(Government == "Communist")
                {
                    msg = "Stalin reaches up from the depths of H*ll and Drags germany down";
                    Government = "Facist";
                }
                if(Government == "Facist")
                {
                    msg = "Hitler is relected.";
                }
                break;

                case "Noah":
                if(Government == "Democractic")
                {
                    msg = "Cold War begins.";
                    Government = "Communist";
                }
                if(Government == "Communist")
                {
                    msg = "Stalin reaches up from the depths of H*ll and Drags America down";
                }
                if(Government == "Facist")
                {
                    msg = "Hitler is rekilled.";
                    Government = "Communist";
                }
                break;

                case "Casino":
                if(cash == 0)
                {
                    msg = "Go Home poor man!";
                    break;
                }
                cash = cash - 5;
                slot1 = (int)(Math.random() * range2) + 1;
                slot2 = (int)(Math.random() * range2) + 1;
                slot3 = (int)(Math.random() * range2) + 1;
                if(slot1 == slot2)
                {
                    msg = "You won the small cash prize!!!";
                    cash = cash + 100;
                    range2 = range2 + 1;
                }
                else if(slot2 == slot3)
                {
                    msg = "You Won a Small cash prize!!!";
                    cash = cash + 100;
                    range2 = range2 + 1;
                }
                else if(slot1 == slot3)
                {
                    msg = "You Won a Small cash prize!!!";
                    cash = cash + 100;
                    range2 = range2 + 1;
                }
                else if(slot2 == slot3 && slot3 == slot1)
                {
                    msg = "You Won a Large cash prize!!!";
                    cash = cash + 1000;
                }
                else
                {
                    msg = "You Win nothing.";
                    range2 = range2 - 1;
                }
                break;   
                case "Song":
                msg = " When a humble bard \n Graced a ride along \n With Geralt of Rivia \n Along came this song \n From when the White Wolf fought \n A silver-tongued devil \n His army of elves \n At his hooves did they revel \n They came after me \n With masterful deceit \n Broke down my lute \n And they kicked in my teeth \n While the devil's horns \n Minced our tender meat \n And so cried the Witcher \n He can't be bleat \n Toss a coin to your Witcher \n O' Valley of Plenty \n O' Valley of Plenty, oh \n Toss a coin to Your Witcher \n O' Valley of Plenty \n At the edge of the world \n Fight the mighty horde \n That bashes and breaks you \n And brings you to mourn \n He thrust every elf \n Far back on the shelf \n High up on the mountain \n From whence it came \n He wiped out your pest \n Got kicked in his chest \n He's a friend of humanity \n So give him the rest \n That's my epic tale \n Our champion prevailed \n Defeated the villain \n Now pour him some ale \n Toss a coin to your Witcher \n O' Valley of Plenty \n O' Valley of Plenty, oh \n Toss a coin to your Witcher \n A friend of humanity \n Toss a coin to your Witcher \n O' Valley of Plenty \n O' Valley of Plenty, oh \n Toss a coin to your Witcher \n A friend of humanity \n Toss a coin to your Witcher \n O' Valley of Plenty \n O' Valley of Plenty, a-oh \n Toss a coin to your Witcher \n A friend of humanity";
                break;
                
                
                
                default: msg ="Enemy Titanfall inbound!";
            }
            
            System.out.println("\n" + msg);
            //delayDots(2);
            //System.out.println("What Now?");
            text = in.nextLine();
        }
    }

    public static String visitCages(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n       " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String lunchtime(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.eat() + ": \n        " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String LookUp(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Flying)
            {
                Flying f =(Flying)a;
                msg += "\n" + a.getName() + ": \n" + f.fly();
            }  
        }
        return msg;
    }

    public static String LookDown(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Swimming)
            {
                Swimming s =(Swimming)a;
                msg += "\n" + a.getName() + ": \n" + s.swim();
            }  
        }
        return msg;
    }

    public static String LookAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Walking)
            {
                Walking w =(Walking)a;
                msg += "\n" + a.getName() + ": \n" + w.walk();
            }  
        }
        return msg;
    }

    public static void populateAnimals(List<Animal> animals)
    {   Bear a1 = new Bear();
        //System.out.println(b);

        GoldFish a2 = new GoldFish();
        //System.out.println(g);

        Husky a3 = new Husky();
        //System.out.println(h);

        Anaconda a4 = new Anaconda();
        //System.out.println(a);

        Bunny a5 = new Bunny();
        //System.out.println(bb);

        Fox a6 = new Fox();
        //System.out.println(f);

        Penguin a7 = new Penguin();
        //System.out.println(p);

        Sheep a8 = new Sheep();
        //System.out.println(s);

        Phish a9 = new Phish();
        //System.out.println(ph);

        droid a10 = new droid();
        //System.out.println(d);

        thwomp a11 = new thwomp();
        //System.out.println(th);

        goomba a12 = new goomba();
        //System.out.println(Go);

        shark a13 = new shark();
        //System.out.println(sh);

        walter a14 = new walter();
        //System.out.println(w);

        Trex a15 = new Trex();
        //System.out.println(Tr);

        platypus a16 = new platypus();
        //System.out.println(pl);

        Llama a17 = new Llama();
        //System.out.println(l);

        FruitBat a18 = new FruitBat();
        //System.out.println(fb);

        Abominablesnowman a19 = new Abominablesnowman();
        //System.out.println(as);

        Bella a20 = new Bella();
        //System.out.println(Be);

        Rhino a21 = new Rhino();
        //System.out.println(rh);

        Vince a22 = new Vince();
        //System.out.println(Vi);

        SunBear a23 = new SunBear();
        //System.out.println(sb);

        Moblin a24 = new Moblin();

        JapaneseMacaque a25 = new JapaneseMacaque();

        Bokoblin a26 = new Bokoblin();

        FleshMonster a27 = new FleshMonster();

        IronTarkus a28 = new IronTarkus();

        Megalodon a29 = new Megalodon();

        JapaneseGiantSalamander a30 = new JapaneseGiantSalamander();

        MourningDove a31 = new MourningDove();

        RedCrowCrane a32 = new RedCrowCrane();

        Duck a33 = new Duck();

        BacterialPhage a35 = new BacterialPhage();

        Lizalfo a34 = new Lizalfo();

        Beholder a36 = new Beholder();

        MindFlayer a37 = new MindFlayer();

        animals.add(a1);
        animals.add(a2);
        animals.add(a3);
        animals.add(a4);
        animals.add(a5);
        animals.add(a6);
        animals.add(a7);
        animals.add(a8);
        animals.add(a9);
        animals.add(a10);
        animals.add(a11);
        animals.add(a12);
        animals.add(a13);
        animals.add(a14);
        animals.add(a15);
        animals.add(a16);
        animals.add(a17);
        animals.add(a18);
        animals.add(a19);
        animals.add(a20);
        animals.add(a21);
        animals.add(a22);
        animals.add(a23);
        animals.add(a24);
        animals.add(a25);
        animals.add(a26);
        animals.add(a27);
        animals.add(a28);
        animals.add(a29);
        animals.add(a30);
        animals.add(a31);
        animals.add(a32);
        animals.add(a33);
        animals.add(a34);
        animals.add(a35);
        animals.add(a36);
        animals.add(a37);
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i = 0; i < dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }
}