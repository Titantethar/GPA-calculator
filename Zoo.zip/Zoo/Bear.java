
/**
 * Write a description of class Rhino here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bear extends Animal
implements Walking
{
    public Bear()
    {
        // initialise instance variables
        this("Black the Bear", "Rar");
    }

    public Bear(String name, String description) {
        super(name, description);
    }
    
    @Override
    public String eat(){
        return "Chews on Seal Fat";
    }
    
    @Override
    public String makeNoise(){
        return "grunt *sniff* *sniff* *sniff* grunt";
    }
    
    @Override
    public String walk()
    {
       return "snow"; 
    }
}
