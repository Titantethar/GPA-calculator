
/**
 * Write a description of class JapaneseGiantSalamander here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JapaneseGiantSalamander extends Animal implements Walking, Swimming
{
    public JapaneseGiantSalamander()
    {
        this("Yui", "Yui's Just Beign Yui");
    }
    
    public JapaneseGiantSalamander(String name, String Decription)
    {
        super(name, Decription);
    }
    
    @Override
    
    public String makeNoise()
    {
       return "Sisssss";
    }
    
    @Override
    
    public String eat()
    {
       return "Slug";
    }
    
    @Override
    
    public String walk()
    {
       return "*Slush**Slush*";
    }
    
    @Override
    
    public String swim()
    {
       return "*Splash**Splash*";
    }
}
