
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class walter extends Animal
implements Walking
{
    /**
     * Constructor for objects of class phish
     */
    public walter()
    {
        this("Walter", " He has a PhD in mechanical engineering.");
    }
    
    public walter(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "aviation biofuel";
    }
    @Override
    public String makeNoise()
    {
        return "metal banging noises";
    }
    @Override
    public String walk()
    {
       return "Walter?"; 
    }
}
