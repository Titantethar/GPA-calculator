/**
 * Write a description of class Sheep here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sheep extends Animal
implements Walking
{
    public Sheep()
    {
        this("Fluffy the sheep", "blah");
    }
   
    public Sheep(String name, String description)
    {
        super(name, description);
    }
   
    @Override
   
    public String eat()
    {
        return "Chews on grass";
    }
   
    @Override
   
    public String makeNoise()
    {
        return "stomp";
    }
    @Override
    public String walk()
    {
       return "Crunch Crunch"; 
    }
}