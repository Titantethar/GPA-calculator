
/**
 * Abstract class Duck - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Duck extends Animal
implements Walking, Swimming, Flying
{
    /**
     * Construction for objects of class Llama
     */
    public Duck()
    {
        this(" Opie the Dopey Duck" , "Enjoys fishing with his father");
        
    }
    
    /**
     * Duck Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Duck(String name, String description) {
        super(name, description);
    }
    
    @Override 
    public String eat()
    {
        return "MMmmm bReAd";
    }
    
    @Override
    public String makeNoise()
    {
        return "Quackk";
    }
    
    @Override
    public String walk()
    {
        return "skitter at the speed of light, hop hop";
    }
    @Override
    public String swim()
    {
        return "submarine mode, water canon enabled";
    }
    @Override
    public String fly()
    {
        return "plumets onto your head with a spear";
    }
}
