
/**
 * Write a description of class Fox here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fox extends Animal
implements Walking
{
    public Fox()
    {
        this("Fred the Fox", "bark");
    }
   
    public Fox(String name, String description)
    {
        super(name, description);
    }
   
    @Override
   
    public String eat()
    {
        return "Chews on fruit";
    }
   
    @Override
   
    public String makeNoise()
    {
        return "meow";
    }
    
    @Override
    public String walk()
    {
       return "Crunch"; 
    }
}