
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class droid extends Animal
implements Walking
{
    /**
     * Constructor for objects of class phish
     */
    public droid()
    {
        this("IG Model Droid", " He has a PhD in spin.");
    }
    
    public droid(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "biokerosene jet fuel";
    }
    @Override
    public String makeNoise()
    {
        return "manufacturers' protocol dictates I cannot be captured. I must self-destruct.";
    }
    @Override
    public String walk()
    {
       return "Clank"; 
    }
}
