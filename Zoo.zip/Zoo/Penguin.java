/**
 * Write a description of class Penguin here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Penguin extends Animal
implements Walking
{
    public Penguin()
    {
        this("Pablo the penguin", "squak");
    }
   
    public Penguin(String name, String description)
    {
        super(name, description);
    }
   
    @Override
   
    public String eat()
    {
        return "eats fish";
    }
   
    @Override
   
    public String makeNoise()
    {
        return "squak";
    }
    
    @Override
    public String walk()
    {
       return "Slip"; 
    }
}