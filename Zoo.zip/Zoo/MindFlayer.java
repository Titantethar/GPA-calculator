
/**
 * Write a description of class MindFlayer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MindFlayer extends Animal implements Flying
{
    public MindFlayer()
    {
        this("Mindflayer Cuthleium", "Your mind is mine. Get it, cause I can control minds.");
    }
    
    public MindFlayer(String name, String description) {
        super(name, description);
    }
    
    @Override
    
    
    public String eat() {
        return "I consume education";
    }
    
    @Override 
    
    
    public String makeNoise() {
        return "Weird tentacle gargling noises.";
    }
    
    @Override
    
    public String fly() {
        return "He looks like he could move with his tentacles but your clearly mistaken.";
    }
}
