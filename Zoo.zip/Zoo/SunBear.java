
/**
 * Write a description of class SunBear here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SunBear extends Animal
    implements Walking
{
    public SunBear()
    {
        this("Sunny", "It's toungue is super long and used to grab food.");
    }
    
    public SunBear(String name, String description) {
        super(name, description);
        //super calls the parent
    }
    
    @Override
    
    public String eat() {
        return "Eat's fruit and meat.";
    }
    
    @Override
    public String makeNoise() {
        return "ROARRRRrrr...";
    }
    
    @Override
    public String walk()
    {
        return "Trample";
    }
}
