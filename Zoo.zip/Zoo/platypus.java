
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class platypus extends Animal
implements Walking
{
    /**
     * Constructor for objects of class phish
     */
    public platypus()
    {
        this("perpryus The platypus", " He has a PhD in nuclear fysics.");
    }
    
    public platypus(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "jet A-1 fuel";
    }
    @Override
    public String makeNoise()
    {
        return "rapidly ghghgh angrily";
    }
    
    @Override
    public String walk()
    {
       return "Does Almost Nothing"; 
    }
}
